<?php
/*
Template Name: 私のカスタムページ
*/

get_header();
?>

<body>
    <section>
        <div class="page-title">
            <h2>Phylosophy</h2>
        </div>
    </section>    
    <section>
        <div class="mission">
            <h3>Mission</h3>
            <p>使命</p>
            <p class="explanation">この文章はダミーです。文字の大きさ、量、字間、行間等を確認するために入れています。</p>
        </div>
        <div class="vision">
            <h3>Vision</h3>
            <p>中長期的に目指す姿</p>
            <p class="explanation">この文章はダミーです。文字の大きさ、量、字間、行間等を確認するために入れています。</p>
        </div>

    </section>

</body>




<?php
get_footer();
?>