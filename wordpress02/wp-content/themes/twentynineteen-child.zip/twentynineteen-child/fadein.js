$(function() {
  // 一旦hide()で隠してフェードインさせる
  $('.table-cell').hide().fadeIn(1000);
 
});