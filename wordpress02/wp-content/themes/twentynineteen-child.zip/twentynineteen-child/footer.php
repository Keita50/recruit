<footer>
    <div class="footer-top clearfix">
        <nav class="ft clearfix">
        <a href="https://www.facebook.com/brainpadrecruit/"><i class="fab fa-facebook fa-2x"></i></a>
        <a href="https://twitter.com/brainpad_pr"><i class="fab fa-twitter-square fa-2x"></i></a>
        </nav>
        <div class="recruit-site clearfix">
            <div class="a">
            <a href="<?php echo get_stylesheet_directory_uri(); ?>/graduate">GRADUATE
            </br>
            新卒採用
            </a>

            </div>
            <div class="b">
            <a href="<?php echo get_stylesheet_directory_uri(); ?>/carrer">CAREER</br>
            中途採用</a>

            </div>
        </div>

    </div>
    <div class="footer-bottom">
    <ul class="foot-ul clearfix">
        <li><a href="">会社概要</a></li>
        <li><a href="">個人情報保護方針</a></li>
        <li><a href="">個人情報の取り扱いについて</a></li>
        <li><a href="">お問い合わせ</a></li>
    </ul>
    </div>
    <p>@keita.igarashi Inc</p>
</footer>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/script.js"></script>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/js/slider.js"></script>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/fadein.js"></script>
</body>